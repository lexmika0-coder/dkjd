// Configuration File
// You can edit this file to change settings without rebuilding the application.
// Note: Telegram credentials are now stored as environment variables on the server

window.APP_CONFIG = {
  // Bot Protection Settings
  // Set to true to redirect known bots to Google
  ENABLE_BOT_PROTECTION: false,
  
  // Where to redirect bots
  BOT_REDIRECT_URL: "https://www.google.com"
};
