import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import EnterCode from "@/pages/enter-code";
import Loading from "@/pages/loading";
import AccessDenied from "@/pages/access-denied";
import { GeoGuard } from "@/components/geo-guard";

function Router() {
  return (
    <GeoGuard>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/enter-code" component={EnterCode} />
        <Route path="/loading" component={Loading} />
        <Route path="/access-denied" component={AccessDenied} />
        <Route component={NotFound} />
      </Switch>
    </GeoGuard>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
