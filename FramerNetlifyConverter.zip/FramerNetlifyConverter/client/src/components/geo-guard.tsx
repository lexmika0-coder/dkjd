import { useEffect, useState, useRef } from "react";
import { useLocation } from "wouter";
import AccessDenied from "@/pages/access-denied";
import { Loader2 } from "lucide-react";

interface GeoGuardProps {
  children: React.ReactNode;
}

const isOnNetlify = () => {
  if (typeof window === 'undefined') return false;
  const hostname = window.location.hostname;
  return hostname.includes('netlify.app') || 
         hostname.includes('netlify.com') || 
         hostname.includes('netlify');
};

const getBlockedIpsEndpoint = (ip?: string) => {
  const isNetlify = isOnNetlify();
  
  // In development/replit, we use the local API
  if (!isNetlify) {
    return ip ? `/api/blocked-ips?ip=${ip}` : '/api/blocked-ips';
  }

  // On Netlify, we use a more robust way to handle the API URL
  const configReplitUrl = window.APP_CONFIG?.REPLIT_API_URL;
  const storageReplitUrl = localStorage.getItem('REPLIT_API_URL');
  const replitUrl = configReplitUrl || storageReplitUrl || '';
  
  if (replitUrl) {
    const base = replitUrl.endsWith('/') ? `${replitUrl}api/blocked-ips` : `${replitUrl}/api/blocked-ips`;
    return ip ? `${base}?ip=${ip}` : base;
  }

  // Fallback to Netlify functions if no Replit URL is provided
  const base = '/.netlify/functions/blocked-ips';
  return ip ? `${base}?ip=${ip}` : base;
};

export function GeoGuard({ children }: GeoGuardProps) {
  const [allowed, setAllowed] = useState<boolean | null>(null);
  const [location] = useLocation();
  const pollingRef = useRef<NodeJS.Timeout | null>(null);

  const checkAccess = async () => {
    // ALWAYS allow in development, replit preview, or netlify dev to avoid "Access Denied" during building/preview
    if (typeof window !== 'undefined' && (
      window.location.hostname === 'localhost' || 
      window.location.hostname.includes('replit.dev') ||
      window.location.hostname.includes('127.0.0.1') ||
      window.location.hostname.includes('netlify.app') // Temporarily allow netlify to verify deployment
    )) {
      setAllowed(true);
      return true;
    }

    const currentIp = sessionStorage.getItem('visitor_ip') || '';
    
    try {
      // Check with specific IP parameter
      if (currentIp) {
        const res = await fetch(getBlockedIpsEndpoint(currentIp));
        if (res.ok) {
          const data = await res.json();
          if (data.blocked === true) {
            setAllowed(false);
            return false;
          }
        }
      }
      
      // Also check if IP is in the blocked list
      const res = await fetch(getBlockedIpsEndpoint());
      if (res.ok) {
        const data = await res.json();
        if (data.blockedIps && currentIp && data.blockedIps.includes(currentIp)) {
          setAllowed(false);
          return false;
        }
      }
    } catch (e) {
      // If check fails, allow access (backend might be down)
      console.error('Failed to check blocked IPs:', e);
    }
    
    setAllowed(true);
    return true;
  };

  // Initial check and check on location change
  useEffect(() => {
    checkAccess();
  }, [location]);

  // Continuous polling to detect if IP gets blocked while on any page
  useEffect(() => {
    pollingRef.current = setInterval(async () => {
      const currentIp = sessionStorage.getItem('visitor_ip') || '';
      if (!currentIp) return;
      
      try {
        const res = await fetch(getBlockedIpsEndpoint(currentIp));
        if (res.ok) {
          const data = await res.json();
          if (data.blocked === true) {
            setAllowed(false);
          }
        }
      } catch (e) {
        // Ignore errors
      }
    }, 2000);

    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
      }
    };
  }, []);

  if (allowed === null) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-white">
        <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
      </div>
    );
  }

  if (allowed === false) {
    return <AccessDenied />;
  }

  return <>{children}</>;
}
