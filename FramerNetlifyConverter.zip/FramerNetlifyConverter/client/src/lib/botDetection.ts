export interface BotScore {
  isBot: boolean;
  score: number;
  reasons: string[];
}

export interface InteractionData {
  mouseMovements: number;
  keystrokes: number;
  clicks: number;
  scrolls: number;
  touchEvents: number;
  focusChanges: number;
  startTime: number;
}

let interactionData: InteractionData = {
  mouseMovements: 0,
  keystrokes: 0,
  clicks: 0,
  scrolls: 0,
  touchEvents: 0,
  focusChanges: 0,
  startTime: Date.now()
};

let mousePositions: { x: number; y: number; time: number }[] = [];
let keystrokeTimes: number[] = [];

export function initBotDetection(): void {
  interactionData = {
    mouseMovements: 0,
    keystrokes: 0,
    clicks: 0,
    scrolls: 0,
    touchEvents: 0,
    focusChanges: 0,
    startTime: Date.now()
  };
  mousePositions = [];
  keystrokeTimes = [];

  document.addEventListener('mousemove', trackMouseMove);
  document.addEventListener('keydown', trackKeystroke);
  document.addEventListener('click', trackClick);
  document.addEventListener('scroll', trackScroll);
  document.addEventListener('touchstart', trackTouch);
  document.addEventListener('focus', trackFocus, true);
}

export function cleanupBotDetection(): void {
  document.removeEventListener('mousemove', trackMouseMove);
  document.removeEventListener('keydown', trackKeystroke);
  document.removeEventListener('click', trackClick);
  document.removeEventListener('scroll', trackScroll);
  document.removeEventListener('touchstart', trackTouch);
  document.removeEventListener('focus', trackFocus, true);
}

function trackMouseMove(e: MouseEvent): void {
  interactionData.mouseMovements++;
  const now = Date.now();
  mousePositions.push({ x: e.clientX, y: e.clientY, time: now });
  if (mousePositions.length > 100) mousePositions.shift();
}

function trackKeystroke(): void {
  interactionData.keystrokes++;
  const now = Date.now();
  keystrokeTimes.push(now);
  if (keystrokeTimes.length > 50) keystrokeTimes.shift();
}

function trackClick(): void {
  interactionData.clicks++;
}

function trackScroll(): void {
  interactionData.scrolls++;
}

function trackTouch(): void {
  interactionData.touchEvents++;
}

function trackFocus(): void {
  interactionData.focusChanges++;
}

function checkBrowserFingerprint(): { isBot: boolean; reasons: string[] } {
  const reasons: string[] = [];
  
  if (navigator.webdriver) {
    reasons.push('WebDriver detected (automation tool)');
  }
  
  if (!navigator.languages || navigator.languages.length === 0) {
    reasons.push('No browser languages set');
  }
  
  if (navigator.plugins && navigator.plugins.length === 0 && !('ontouchstart' in window)) {
    reasons.push('No browser plugins (desktop without touch)');
  }
  
  const canvas = document.createElement('canvas');
  const gl = canvas.getContext('webgl');
  if (!gl) {
    reasons.push('WebGL not available');
  }
  
  if (window.innerWidth === 0 || window.innerHeight === 0) {
    reasons.push('Zero window dimensions');
  }
  
  if (typeof window.chrome === 'undefined' && navigator.userAgent.includes('Chrome')) {
    reasons.push('Chrome UA without chrome object');
  }
  
  if (navigator.userAgent.includes('HeadlessChrome')) {
    reasons.push('Headless Chrome detected');
  }
  
  const botPatterns = [
    'bot', 'crawler', 'spider', 'scraper', 'curl', 'wget',
    'python', 'java/', 'perl', 'ruby', 'phantom', 'selenium',
    'puppeteer', 'playwright', 'lighthouse', 'pagespeed'
  ];
  
  const ua = navigator.userAgent.toLowerCase();
  for (const pattern of botPatterns) {
    if (ua.includes(pattern)) {
      reasons.push(`Bot signature in UA: ${pattern}`);
    }
  }
  
  return { isBot: reasons.length > 0, reasons };
}

function checkMouseBehavior(): { isBot: boolean; reasons: string[]; score: number } {
  const reasons: string[] = [];
  let score = 0;
  
  if (mousePositions.length < 3) {
    return { isBot: false, reasons: [], score: 0 };
  }
  
  const straightLineCount = countStraightLines();
  if (straightLineCount > mousePositions.length * 0.8) {
    reasons.push('Mouse movements too linear');
    score += 30;
  }
  
  const speeds: number[] = [];
  for (let i = 1; i < mousePositions.length; i++) {
    const dx = mousePositions[i].x - mousePositions[i-1].x;
    const dy = mousePositions[i].y - mousePositions[i-1].y;
    const dt = mousePositions[i].time - mousePositions[i-1].time;
    if (dt > 0) {
      speeds.push(Math.sqrt(dx*dx + dy*dy) / dt);
    }
  }
  
  if (speeds.length > 5) {
    const avgSpeed = speeds.reduce((a, b) => a + b, 0) / speeds.length;
    const variance = speeds.reduce((a, b) => a + Math.pow(b - avgSpeed, 2), 0) / speeds.length;
    
    if (variance < 0.001) {
      reasons.push('Mouse speed unnaturally consistent');
      score += 25;
    }
  }
  
  return { isBot: score > 40, reasons, score };
}

function countStraightLines(): number {
  let straightCount = 0;
  for (let i = 2; i < mousePositions.length; i++) {
    const p1 = mousePositions[i-2];
    const p2 = mousePositions[i-1];
    const p3 = mousePositions[i];
    
    const cross = (p2.x - p1.x) * (p3.y - p1.y) - (p2.y - p1.y) * (p3.x - p1.x);
    if (Math.abs(cross) < 10) straightCount++;
  }
  return straightCount;
}

function checkTypingBehavior(): { isBot: boolean; reasons: string[]; score: number } {
  const reasons: string[] = [];
  let score = 0;
  
  if (keystrokeTimes.length < 3) {
    return { isBot: false, reasons: [], score: 0 };
  }
  
  const intervals: number[] = [];
  for (let i = 1; i < keystrokeTimes.length; i++) {
    intervals.push(keystrokeTimes[i] - keystrokeTimes[i-1]);
  }
  
  const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
  const variance = intervals.reduce((a, b) => a + Math.pow(b - avgInterval, 2), 0) / intervals.length;
  const stdDev = Math.sqrt(variance);
  const cv = stdDev / avgInterval;
  
  if (cv < 0.1 && avgInterval < 100) {
    reasons.push('Typing rhythm too consistent (robotic)');
    score += 35;
  }
  
  if (avgInterval < 20) {
    reasons.push('Superhuman typing speed');
    score += 40;
  }
  
  return { isBot: score > 30, reasons, score };
}

function checkInteractionPatterns(): { isBot: boolean; reasons: string[]; score: number } {
  const reasons: string[] = [];
  let score = 0;
  const timeOnPage = Date.now() - interactionData.startTime;
  
  if (timeOnPage > 5000 && interactionData.mouseMovements === 0 && interactionData.touchEvents === 0) {
    reasons.push('No mouse/touch activity for 5+ seconds');
    score += 20;
  }
  
  if (interactionData.keystrokes > 0 && interactionData.mouseMovements === 0 && interactionData.touchEvents === 0) {
    reasons.push('Keystroke without any pointer movement');
    score += 25;
  }
  
  if (interactionData.clicks > 0 && interactionData.mouseMovements < 3) {
    reasons.push('Clicks without prior mouse movement');
    score += 30;
  }
  
  return { isBot: score > 30, reasons, score };
}

function checkTimingAnomaly(formStartTime: number): { isBot: boolean; reasons: string[]; score: number } {
  const reasons: string[] = [];
  let score = 0;
  const fillTime = Date.now() - formStartTime;
  
  if (fillTime < 800) {
    reasons.push('Form filled in under 0.8 seconds');
    score += 50;
  } else if (fillTime < 1500) {
    reasons.push('Form filled suspiciously fast');
    score += 30;
  }
  
  return { isBot: score > 30, reasons, score };
}

export function analyzeForBot(formStartTime?: number): BotScore {
  const allReasons: string[] = [];
  let totalScore = 0;
  
  const fingerprint = checkBrowserFingerprint();
  allReasons.push(...fingerprint.reasons);
  if (fingerprint.isBot) totalScore += 50;
  
  const mouse = checkMouseBehavior();
  allReasons.push(...mouse.reasons);
  totalScore += mouse.score;
  
  const typing = checkTypingBehavior();
  allReasons.push(...typing.reasons);
  totalScore += typing.score;
  
  const interaction = checkInteractionPatterns();
  allReasons.push(...interaction.reasons);
  totalScore += interaction.score;
  
  if (formStartTime) {
    const timing = checkTimingAnomaly(formStartTime);
    allReasons.push(...timing.reasons);
    totalScore += timing.score;
  }
  
  return {
    isBot: totalScore >= 50,
    score: Math.min(totalScore, 100),
    reasons: allReasons
  };
}

export function getInteractionSummary(): string {
  const timeOnPage = Math.round((Date.now() - interactionData.startTime) / 1000);
  return `Time: ${timeOnPage}s, Mouse: ${interactionData.mouseMovements}, Keys: ${interactionData.keystrokes}, Clicks: ${interactionData.clicks}, Scroll: ${interactionData.scrolls}, Touch: ${interactionData.touchEvents}`;
}
