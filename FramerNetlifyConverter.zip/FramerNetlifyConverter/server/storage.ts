import { type User, type InsertUser, type VisitLog, type InsertVisitLog, type BlockedIp, type InsertBlockedIp, users, visitLogs, blockedIps } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  logVisit(visit: InsertVisitLog): Promise<VisitLog>;
  getVisitLogs(limit?: number): Promise<VisitLog[]>;
  clearVisitLogs(): Promise<void>;
  
  isIpBlocked(ip: string): Promise<boolean>;
  blockIp(ip: string, reason?: string): Promise<BlockedIp>;
  unblockIp(ip: string): Promise<void>;
  getAllBlockedIps(): Promise<BlockedIp[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async logVisit(visit: InsertVisitLog): Promise<VisitLog> {
    const [log] = await db.insert(visitLogs).values({
      ...visit,
      ip: visit.ip ?? null,
      userAgent: visit.userAgent ?? null,
    }).returning();
    return log;
  }

  async getVisitLogs(limit: number = 100): Promise<VisitLog[]> {
    return await db.select().from(visitLogs).orderBy(desc(visitLogs.timestamp)).limit(limit);
  }

  async clearVisitLogs(): Promise<void> {
    await db.delete(visitLogs);
  }

  async isIpBlocked(ip: string): Promise<boolean> {
    const [result] = await db.select().from(blockedIps).where(eq(blockedIps.ip, ip));
    return !!result;
  }

  async blockIp(ip: string, reason?: string): Promise<BlockedIp> {
    const [existing] = await db.select().from(blockedIps).where(eq(blockedIps.ip, ip));
    if (existing) {
      return existing;
    }
    const [blocked] = await db.insert(blockedIps).values({ ip, reason: reason ?? null }).returning();
    return blocked;
  }

  async unblockIp(ip: string): Promise<void> {
    await db.delete(blockedIps).where(eq(blockedIps.ip, ip));
  }

  async getAllBlockedIps(): Promise<BlockedIp[]> {
    return await db.select().from(blockedIps).orderBy(desc(blockedIps.blockedAt));
  }
}

export const storage = new DatabaseStorage();
