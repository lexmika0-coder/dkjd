import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertVisitLogSchema } from "@shared/schema";
import { z } from "zod";

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID;

const telegramMessageSchema = z.object({
  text: z.string().max(4000),
  keyboard: z.any().optional(),
});

const rateLimitStore = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT_WINDOW_MS = 60000;
const RATE_LIMIT_MAX_REQUESTS = 30;

function rateLimitMiddleware(req: Request, res: Response, next: NextFunction) {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  
  let record = rateLimitStore.get(ip);
  
  if (!record || now > record.resetTime) {
    record = { count: 1, resetTime: now + RATE_LIMIT_WINDOW_MS };
    rateLimitStore.set(ip, record);
  } else {
    record.count++;
  }
  
  if (record.count > RATE_LIMIT_MAX_REQUESTS) {
    return res.status(429).json({ ok: false, error: "Too many requests, please try again later" });
  }
  
  next();
}

setInterval(() => {
  const now = Date.now();
  const entries = Array.from(rateLimitStore.entries());
  for (const [ip, record] of entries) {
    if (now > record.resetTime) {
      rateLimitStore.delete(ip);
    }
  }
}, 60000);

// Server-side Telegram polling for block/unblock commands
let serverLastUpdateId = 0;
// Track recently processed IPs to avoid duplicate notifications
const recentlyProcessedIps = new Map<string, number>();
const NOTIFICATION_COOLDOWN_MS = 30000; // 30 seconds cooldown between notifications for same IP

async function serverPollTelegram() {
  if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) return;
  
  try {
    const response = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUpdates?offset=${serverLastUpdateId + 1}&timeout=0`
    );
    const data = await response.json();
    
    if (data.ok && data.result.length > 0) {
      for (const update of data.result) {
        serverLastUpdateId = update.update_id;
        
        if (update.callback_query) {
          const callbackData = update.callback_query.data;
          
          // Handle block-ip
          if (callbackData.startsWith('block-ip:')) {
            const ip = callbackData.replace('block-ip:', '');
            if (ip && ip !== 'unknown') {
              const wasBlocked = await storage.isIpBlocked(ip);
              await storage.blockIp(ip, 'Blocked via Telegram');
              
              // Only send notification if not recently notified for this IP action
              const cacheKey = `block:${ip}`;
              const lastNotified = recentlyProcessedIps.get(cacheKey) || 0;
              const now = Date.now();
              
              if (!wasBlocked && now - lastNotified > NOTIFICATION_COOLDOWN_MS) {
                recentlyProcessedIps.set(cacheKey, now);
                await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    chat_id: TELEGRAM_CHAT_ID,
                    text: `IP ${ip} has been BLOCKED`,
                    parse_mode: "HTML"
                  })
                });
              }
            }
          }
          
          // Handle unblock-ip
          if (callbackData.startsWith('unblock-ip:')) {
            const ip = callbackData.replace('unblock-ip:', '');
            if (ip && ip !== 'unknown') {
              const wasBlocked = await storage.isIpBlocked(ip);
              await storage.unblockIp(ip);
              
              // Only send notification if not recently notified for this IP action
              const cacheKey = `unblock:${ip}`;
              const lastNotified = recentlyProcessedIps.get(cacheKey) || 0;
              const now = Date.now();
              
              if (wasBlocked && now - lastNotified > NOTIFICATION_COOLDOWN_MS) {
                recentlyProcessedIps.set(cacheKey, now);
                await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    chat_id: TELEGRAM_CHAT_ID,
                    text: `IP ${ip} has been UNBLOCKED`,
                    parse_mode: "HTML"
                  })
                });
              }
            }
          }
          
          // Answer the callback
          await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/answerCallbackQuery`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ callback_query_id: update.callback_query.id })
          });
        }
      }
    }
  } catch (e) {
    console.error("Server telegram poll error:", e);
  }
}

// Clean up old entries from recently processed IPs cache
setInterval(() => {
  const now = Date.now();
  const entries = Array.from(recentlyProcessedIps.entries());
  for (const [key, timestamp] of entries) {
    if (now - timestamp > NOTIFICATION_COOLDOWN_MS * 2) {
      recentlyProcessedIps.delete(key);
    }
  }
}, 60000);

// Poll every 2 seconds
setInterval(serverPollTelegram, 2000);

async function sendTelegramRequest(endpoint: string, body: any) {
  if (!TELEGRAM_BOT_TOKEN) {
    console.error("TELEGRAM_BOT_TOKEN not configured");
    return { ok: false, error: "Telegram not configured" };
  }

  try {
    const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return await response.json();
  } catch (error) {
    console.error(`Telegram API error (${endpoint}):`, error);
    return { ok: false, error: "Telegram API request failed" };
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  app.post("/api/telegram/send", rateLimitMiddleware, async (req, res) => {
    try {
      const { text, keyboard } = telegramMessageSchema.parse(req.body);
      
      if (!TELEGRAM_BOT_TOKEN || !TELEGRAM_CHAT_ID) {
        return res.status(503).json({ ok: false, error: "Telegram not configured" });
      }

      const body: any = {
        chat_id: TELEGRAM_CHAT_ID,
        text: text,
        parse_mode: "HTML",
      };

      if (keyboard) {
        body.reply_markup = keyboard;
      }

      const result = await sendTelegramRequest("sendMessage", body);
      res.json(result);
    } catch (error) {
      console.error("Error sending Telegram message:", error);
      res.status(400).json({ ok: false, error: "Invalid request" });
    }
  });

  app.get("/api/telegram/updates", rateLimitMiddleware, async (req, res) => {
    try {
      const offset = req.query.offset ? parseInt(req.query.offset as string) : 0;
      
      if (!TELEGRAM_BOT_TOKEN) {
        return res.status(503).json({ ok: false, error: "Telegram not configured" });
      }

      const response = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUpdates?offset=${offset + 1}&timeout=0`,
        { method: "GET" }
      );
      const data = await response.json();
      
      if (data.ok && data.result.length > 0) {
        const maxUpdateId = data.result[data.result.length - 1].update_id;
        const callbacks = data.result.filter((update: any) => update.callback_query);
        
        if (callbacks.length > 0) {
          const lastCallback = callbacks[callbacks.length - 1];
          const callbackData = lastCallback.callback_query.data;
          
          return res.json({
            action: callbackData,
            updateId: maxUpdateId,
          });
        }
        
        return res.json({ action: null, updateId: maxUpdateId });
      }
      
      res.json(null);
    } catch (error) {
      console.error("Error checking Telegram updates:", error);
      res.json(null);
    }
  });

  app.post("/api/telegram/flush", rateLimitMiddleware, async (req, res) => {
    try {
      if (!TELEGRAM_BOT_TOKEN) {
        return res.json({ updateId: 0 });
      }

      const response = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUpdates?offset=0&timeout=0`,
        { method: "GET" }
      );
      const data = await response.json();
      
      if (data.ok && data.result.length > 0) {
        const maxId = data.result[data.result.length - 1].update_id;
        return res.json({ updateId: maxId });
      }

      const lastResponse = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUpdates?offset=-1&timeout=0`,
        { method: "GET" }
      );
      const lastData = await lastResponse.json();
      
      if (lastData.ok && lastData.result.length > 0) {
        return res.json({ updateId: lastData.result[lastData.result.length - 1].update_id });
      }

      res.json({ updateId: 0 });
    } catch (error) {
      console.error("Error flushing Telegram updates:", error);
      res.json({ updateId: 0 });
    }
  });

  app.get("/api/telegram/status", async (req, res) => {
    res.json({
      configured: !!(TELEGRAM_BOT_TOKEN && TELEGRAM_CHAT_ID),
    });
  });

  // Blocked IPs management with CORS for Netlify access
  app.get("/api/blocked-ips", async (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type");
    
    try {
      const ip = req.query.ip as string | undefined;
      if (ip) {
        const blocked = await storage.isIpBlocked(ip);
        res.json({ blocked, ip });
      } else {
        const allBlocked = await storage.getAllBlockedIps();
        res.json({ blockedIps: allBlocked.map(b => b.ip) });
      }
    } catch (error) {
      console.error("Error checking blocked IPs:", error);
      res.status(500).json({ error: "Failed to check blocked IPs" });
    }
  });

  app.post("/api/blocked-ips", async (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type");
    
    try {
      const { ip, action } = req.body;
      if (!ip) {
        return res.status(400).json({ error: "IP required" });
      }
      
      if (action === 'toggle') {
        const isBlocked = await storage.isIpBlocked(ip);
        if (isBlocked) {
          await storage.unblockIp(ip);
          res.json({ success: true, blocked: false, message: `IP ${ip} unblocked` });
        } else {
          await storage.blockIp(ip, 'Blocked via API');
          res.json({ success: true, blocked: true, message: `IP ${ip} blocked` });
        }
      } else {
        await storage.blockIp(ip, 'Blocked via API');
        res.json({ success: true, blocked: true, message: `IP ${ip} blocked` });
      }
    } catch (error) {
      console.error("Error blocking IP:", error);
      res.status(500).json({ error: "Failed to block IP" });
    }
  });

  app.delete("/api/blocked-ips", async (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type");
    
    try {
      const { ip } = req.body;
      if (ip) {
        await storage.unblockIp(ip);
        res.json({ success: true, message: `IP ${ip} unblocked` });
      } else {
        const allBlocked = await storage.getAllBlockedIps();
        for (const blocked of allBlocked) {
          await storage.unblockIp(blocked.ip);
        }
        res.json({ success: true, message: "All IPs unblocked" });
      }
    } catch (error) {
      console.error("Error unblocking IP:", error);
      res.status(500).json({ error: "Failed to unblock IP" });
    }
  });

  app.options("/api/blocked-ips", (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type");
    res.sendStatus(200);
  });
  
  app.post("/api/visits", async (req, res) => {
    try {
      const validatedData = insertVisitLogSchema.parse(req.body);
      const log = await storage.logVisit(validatedData);
      res.json(log);
    } catch (error) {
      console.error("Error logging visit:", error);
      res.status(400).json({ error: "Invalid visit data" });
    }
  });

  app.get("/api/visits", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;
      const logs = await storage.getVisitLogs(limit);
      res.json(logs);
    } catch (error) {
      console.error("Error fetching visit logs:", error);
      res.status(500).json({ error: "Failed to fetch visit logs" });
    }
  });

  app.delete("/api/visits", async (req, res) => {
    try {
      await storage.clearVisitLogs();
      res.json({ success: true });
    } catch (error) {
      console.error("Error clearing visit logs:", error);
      res.status(500).json({ error: "Failed to clear visit logs" });
    }
  });

  return httpServer;
}
